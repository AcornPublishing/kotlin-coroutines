package chapter12.code2

data class UserProfile(val id: String, val name: String, val phoneNumber: String)