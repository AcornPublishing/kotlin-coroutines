package chapter2.code1

import kotlinx.coroutines.*

fun main() = runBlocking<Unit> {
  println("Hello Coroutines")
}