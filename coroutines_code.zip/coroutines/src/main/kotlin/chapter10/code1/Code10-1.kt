package chapter10.code1

fun routine() {
  routineA() // routineA는 routine의 서브루틴이다.
  routineB() // routineB는 routine의 서브루틴이다.
}

fun routineA() {
  // ...
}

fun routineB() {
  // ...
}