package chapter1.code1

fun main() {
  println("Hello World!")
}
/*
// 결과:
Hello World! // 메인 스레드가 prinln("Hello World") 실행

Process finished with exit code 0 // 프로세스가 정상적으로 종료
*/
